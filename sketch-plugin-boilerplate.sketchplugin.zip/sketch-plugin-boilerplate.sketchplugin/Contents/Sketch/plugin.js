var handlers =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = initWithContext;
/* unused harmony export loadFramework */
/* unused harmony export context */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return document; });
/* unused harmony export selection */
/* unused harmony export Library */
/* unused harmony export page */
/* unused harmony export sketch */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return pluginFolderPath; });
var context = null;
var document = null;
var Library = null;
var page = null;
var selection = null;
var sketch = null;

var pluginFolderPath = null;
var frameworkFolderPath = '/Contents/Resources/frameworks/';

function getPluginFolderPath() {
  // Get absolute folder path of plugin
  var split = context.scriptPath.split('/');
  split.splice(-3, 3);
  return split.join('/');
}

function initWithContext(ctx) {
  // This function needs to be called in the beginning of every entry point!
  // Set all env variables according to current context
  context = ctx;
  document = ctx.document || ctx.actionContext.document || MSDocument.currentDocument();
  selection = document ? document.selectedLayers() : null;
  page = document ? document.SelectedPage : null;
  pluginFolderPath = getPluginFolderPath();

  // Here you could load custom cocoa frameworks if you need to
  // loadFramework('FrameworkName', 'ClassName');
  // => would be loaded into ClassName in global namespace!
}

function loadFramework(frameworkName, frameworkClass) {
  // Only load framework if class not already available
  if (Mocha && NSClassFromString(frameworkClass) == null) {
    var frameworkDir = '' + pluginFolderPath + frameworkFolderPath;
    var mocha = Mocha.sharedRuntime();
    return mocha.loadFrameworkWithName_inDirectory(frameworkName, frameworkDir);
  }
  return false;
}



/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export BridgeMessageHandler */
/* unused harmony export initBridgedWebView */
/* unused harmony export getFilePath */
/* harmony export (immutable) */ __webpack_exports__["a"] = createWebView;
/* harmony export (immutable) */ __webpack_exports__["c"] = sendAction;
/* unused harmony export receiveAction */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return windowIdentifier; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return panelIdentifier; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__core__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_cocoascript_class__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_cocoascript_class___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_cocoascript_class__);



// These are just used to identify the window(s)
// Change them to whatever you need e.g. if you need to support multiple
// windows at the same time...
var windowIdentifier = 'sketch-plugin-boilerplate--window';
var panelIdentifier = 'sketch-plugin-boilerplate--panel';

// Since we now create the delegate in js, we need the enviroment
// to stick around for as long as we need a reference to that delegate
coscript.setShouldKeepAround(true);

// This is a helper delegate, that handles incoming bridge messages
var BridgeMessageHandler = new __WEBPACK_IMPORTED_MODULE_1_cocoascript_class___default.a({
  'userContentController:didReceiveScriptMessage:': function userContentControllerDidReceiveScriptMessage(controller, message) {
    try {
      var bridgeMessage = JSON.parse(String(message.body()));
      receiveAction(bridgeMessage.name, bridgeMessage.data);
    } catch (e) {
      log('Could not parse bridge message');
      log(e.message);
    }
  }
});

log('BridgeMessageHandler');
log(BridgeMessageHandler);
log(BridgeMessageHandler.userContentController_didReceiveScriptMessage);

function initBridgedWebView(frame) {
  var bridgeName = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'SketchBridge';

  var config = WKWebViewConfiguration.alloc().init();
  var messageHandler = BridgeMessageHandler.alloc().init();
  config.userContentController().addScriptMessageHandler_name(messageHandler, bridgeName);
  return WKWebView.alloc().initWithFrame_configuration(frame, config);
}

function getFilePath(file) {
  return __WEBPACK_IMPORTED_MODULE_0__core__["c" /* pluginFolderPath */] + '/Contents/Resources/webview/' + file;
}

function createWebView(path, frame) {
  var webView = initBridgedWebView(frame, 'Sketch');
  var url = NSURL.fileURLWithPath(getFilePath(path));
  log('File URL');
  log(url);

  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable);
  webView.loadRequest(NSURLRequest.requestWithURL(url));

  return webView;
}

function sendAction(webView, name) {
  var payload = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  if (!webView || !webView.evaluateJavaScript_completionHandler) {
    return;
  }
  // `sketchBridge` is the JS function exposed on window in the webview!
  var script = 'sketchBridge(\'' + JSON.stringify({ name: name, payload: payload }) + '\');';
  webView.evaluateJavaScript_completionHandler(name);
}

function receiveAction() {
  var name = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

  __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].showMessage('Generating a ' + name.size.slice(3) + ' Datatable with ' + name.cols + ' Columns & ' + name.rows + ' Rows!');

  var sketch = __webpack_require__(!(function webpackMissingModule() { var e = new Error("Cannot find module \"sketch\""); e.code = 'MODULE_NOT_FOUND'; throw e; }()));
  var dom = __webpack_require__(!(function webpackMissingModule() { var e = new Error("Cannot find module \"sketch/dom\""); e.code = 'MODULE_NOT_FOUND'; throw e; }())).dom;
  var Library = __webpack_require__(!(function webpackMissingModule() { var e = new Error("Cannot find module \"sketch/dom\""); e.code = 'MODULE_NOT_FOUND'; throw e; }())).Library;
  var Artboard = sketch.Artboard;

  var page = __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].getSelectedPage;
  var artboard = page.layers.find(function (obj) {
    return obj.selected === true;
  });

  var selectedLayers = __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].selectedLayers;
  var selectedCount = selectedLayers.length;

  var rows = name.rows;
  var cols = name.cols;
  var size = name.size;
  var theme = name.theme;

  var allLibs = Library.getLibraries();

  var icgdsLightLib = allLibs.find(function (obj) {
    return obj.name === '02 ICG DS - Components (' + theme + ') (DSM)';
  });

  var symbolReferences = icgdsLightLib.getImportableSymbolReferencesForDocument(__WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */]);

  var headerCell = symbolReferences.find(function (obj) {
    return obj.name == 'Data Table/Cell/' + size + '/01 Column Header/01 Standard/01 Standard- Left Aligned';
  });
  var tableCell = symbolReferences.find(function (obj) {
    return obj.name == 'Data Table/ Cell/' + size + '/02 Standard Cell/ 01 Text (Left Align)/ 01 Default';
  });

  //create and position header
  for (var i = 0; i < cols; i++) {

    var symbol = headerCell.import();
    var instance = symbol.createNewInstance();
    var width = instance.frame.width;

    instance.frame.x = instance.frame.x + width * i;
    instance.parent = artboard;
  }

  //create and position rest of cells
  for (var y = 0; y < rows; y++) {

    var symbolY = tableCell.import();
    var instanceY = symbolY.createNewInstance();
    var height = instanceY.frame.height;

    instanceY.frame.y = instanceY.frame.y + height * y + parseInt(size.slice('0,2'));
    instanceY.parent = artboard;

    for (var x = 0; x < cols; x++) {

      var symbolX = tableCell.import();
      var instanceX = symbolX.createNewInstance();
      var _width = instanceX.frame.width;

      instanceX.frame.x = instanceX.frame.x + _width * x;
      instanceX.frame.y = instanceY.frame.y;
      instance.parent = artboard;
    }
  }
}



/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony export (immutable) */ __webpack_exports__["helloWorld"] = helloWorld;
/* harmony export (immutable) */ __webpack_exports__["openWindow"] = openWindow;
/* harmony export (immutable) */ __webpack_exports__["togglePanel"] = togglePanel;
/* harmony export (immutable) */ __webpack_exports__["sendMessageToWindow"] = sendMessageToWindow;
/* harmony export (immutable) */ __webpack_exports__["sendMessageToPanel"] = sendMessageToPanel;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__utils_core__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__utils_webview__ = __webpack_require__(3);



// All exported functions will be exposed as entry points to your plugin
// and can be referenced in your `manifest.json`

function helloWorld(context) {
  Object(__WEBPACK_IMPORTED_MODULE_0__utils_core__["b" /* initWithContext */])(context);
  __WEBPACK_IMPORTED_MODULE_0__utils_core__["a" /* document */].showMessage('👋🌏 Hello World!');
}

function openWindow(context) {
  // It's good practice to have an init function, that can be called
  // at the beginning of all entry points and will prepare the enviroment
  // using the provided `context`
  Object(__WEBPACK_IMPORTED_MODULE_0__utils_core__["b" /* initWithContext */])(context);
  __WEBPACK_IMPORTED_MODULE_1__utils_webview__["a" /* openWindow */](__WEBPACK_IMPORTED_MODULE_1__utils_webview__["f" /* windowIdentifier */]);
}

function togglePanel(context) {
  Object(__WEBPACK_IMPORTED_MODULE_0__utils_core__["b" /* initWithContext */])(context);
  __WEBPACK_IMPORTED_MODULE_1__utils_webview__["e" /* togglePanel */](__WEBPACK_IMPORTED_MODULE_1__utils_webview__["b" /* panelIdentifier */]);
}

function sendMessageToWindow(context) {
  Object(__WEBPACK_IMPORTED_MODULE_0__utils_core__["b" /* initWithContext */])(context);
  __WEBPACK_IMPORTED_MODULE_1__utils_webview__["d" /* sendWindowAction */](__WEBPACK_IMPORTED_MODULE_1__utils_webview__["f" /* windowIdentifier */], 'foo', { foo: 'bar' });
}

function sendMessageToPanel(context) {
  Object(__WEBPACK_IMPORTED_MODULE_0__utils_core__["b" /* initWithContext */])(context);
  __WEBPACK_IMPORTED_MODULE_1__utils_webview__["c" /* sendPanelAction */](__WEBPACK_IMPORTED_MODULE_1__utils_webview__["b" /* panelIdentifier */], 'foo', { foo: 'bar' });
}

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__webview__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__window__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__panel__ = __webpack_require__(7);
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return __WEBPACK_IMPORTED_MODULE_0__webview__["d"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return __WEBPACK_IMPORTED_MODULE_0__webview__["b"]; });
/* unused harmony reexport getFilePath */
/* unused harmony reexport createWebView */
/* unused harmony reexport sendActionToWebView */
/* unused harmony reexport receiveAction */
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return __WEBPACK_IMPORTED_MODULE_1__window__["a"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return __WEBPACK_IMPORTED_MODULE_1__window__["b"]; });
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return __WEBPACK_IMPORTED_MODULE_2__panel__["b"]; });
/* unused harmony reexport openPanel */
/* unused harmony reexport closePanel */
/* unused harmony reexport isPanelOpen */
/* harmony reexport (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return __WEBPACK_IMPORTED_MODULE_2__panel__["a"]; });








/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = undefined;
exports.default = ObjCClass;

var _runtime = __webpack_require__(5);

exports.SuperCall = _runtime.SuperCall;

// super when returnType is id and args are void
// id objc_msgSendSuper(struct objc_super *super, SEL op, void)

const SuperInit = (0, _runtime.SuperCall)(NSStringFromSelector("init"), [], { type: "@" });

// Returns a real ObjC class. No need to use new.
function ObjCClass(defn) {
  const superclass = defn.superclass || NSObject;
  const className = (defn.className || defn.classname || "ObjCClass") + NSUUID.UUID().UUIDString();
  const reserved = new Set(['className', 'classname', 'superclass']);
  var cls = MOClassDescription.allocateDescriptionForClassWithName_superclass_(className, superclass);
  // Add each handler to the class description
  const ivars = [];
  for (var key in defn) {
    const v = defn[key];
    if (typeof v == 'function' && key !== 'init') {
      var selector = NSSelectorFromString(key);
      cls.addInstanceMethodWithSelector_function_(selector, v);
    } else if (!reserved.has(key)) {
      ivars.push(key);
      cls.addInstanceVariableWithName_typeEncoding(key, "@");
    }
  }

  cls.addInstanceMethodWithSelector_function_(NSSelectorFromString('init'), function () {
    const self = SuperInit.call(this);
    ivars.map(name => {
      Object.defineProperty(self, name, {
        get() {
          return getIvar(self, name);
        },
        set(v) {
          (0, _runtime.object_setInstanceVariable)(self, name, v);
        }
      });
      self[name] = defn[name];
    });
    // If there is a passsed-in init funciton, call it now.
    if (typeof defn.init == 'function') defn.init.call(this);
    return self;
  });

  return cls.registerClass();
};

function getIvar(obj, name) {
  const retPtr = MOPointer.new();
  (0, _runtime.object_getInstanceVariable)(obj, name, retPtr);
  return retPtr.value().retain().autorelease();
}

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SuperCall = SuperCall;
exports.CFunc = CFunc;
const objc_super_typeEncoding = '{objc_super="receiver"@"super_class"#}';

// You can store this to call your function. this must be bound to the current instance.
function SuperCall(selector, argTypes, returnType) {
  const func = CFunc("objc_msgSendSuper", [{ type: '^' + objc_super_typeEncoding }, { type: ":" }, ...argTypes], returnType);
  return function (...args) {
    const struct = make_objc_super(this, this.superclass());
    const structPtr = MOPointer.alloc().initWithValue_(struct);
    return func(structPtr, selector, ...args);
  };
}

// Recursively create a MOStruct
function makeStruct(def) {
  if (typeof def !== 'object' || Object.keys(def).length == 0) {
    return def;
  }
  const name = Object.keys(def)[0];
  const values = def[name];

  const structure = MOStruct.structureWithName_memberNames_runtime(name, Object.keys(values), Mocha.sharedRuntime());

  Object.keys(values).map(member => {
    structure[member] = makeStruct(values[member]);
  });

  return structure;
}

function make_objc_super(self, cls) {
  return makeStruct({
    objc_super: {
      receiver: self,
      super_class: cls
    }
  });
}

// Due to particularities of the JS bridge, we can't call into MOBridgeSupport objects directly
// But, we can ask key value coding to do the dirty work for us ;)
function setKeys(o, d) {
  const funcDict = NSMutableDictionary.dictionary();
  funcDict.o = o;
  Object.keys(d).map(k => funcDict.setValue_forKeyPath(d[k], "o." + k));
}

// Use any C function, not just ones with BridgeSupport
function CFunc(name, args, retVal) {
  function makeArgument(a) {
    if (!a) return null;
    const arg = MOBridgeSupportArgument.alloc().init();
    setKeys(arg, {
      type64: a.type
    });
    return arg;
  }
  const func = MOBridgeSupportFunction.alloc().init();
  setKeys(func, {
    name: name,
    arguments: args.map(makeArgument),
    returnValue: makeArgument(retVal)
  });
  return func;
}

/*
@encode(char*) = "*"
@encode(id) = "@"
@encode(Class) = "#"
@encode(void*) = "^v"
@encode(CGRect) = "{CGRect={CGPoint=dd}{CGSize=dd}}"
@encode(SEL) = ":"
*/

function addStructToBridgeSupport(key, structDef) {
  // OK, so this is probably the nastiest hack in this file.
  // We go modify MOBridgeSupportController behind its back and use kvc to add our own definition
  // There isn't another API for this though. So the only other way would be to make a real bridgesupport file.
  const symbols = MOBridgeSupportController.sharedController().valueForKey('symbols');
  if (!symbols) throw Error("Something has changed within bridge support so we can't add our definitions");
  // If someone already added this definition, don't re-register it.
  if (symbols[key] !== null) return;
  const def = MOBridgeSupportStruct.alloc().init();
  setKeys(def, {
    name: key,
    type: structDef.type
  });
  symbols[key] = def;
};

// This assumes the ivar is an object type. Return value is pretty useless.
const object_getInstanceVariable = exports.object_getInstanceVariable = CFunc("object_getInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "^@" }], { type: "^{objc_ivar=}" });
// Again, ivar is of object type
const object_setInstanceVariable = exports.object_setInstanceVariable = CFunc("object_setInstanceVariable", [{ type: "@" }, { type: '*' }, { type: "@" }], { type: "^{objc_ivar=}" });

// We need Mocha to understand what an objc_super is so we can use it as a function argument
addStructToBridgeSupport('objc_super', { type: objc_super_typeEncoding });

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = open;
/* unused harmony export findWebView */
/* harmony export (immutable) */ __webpack_exports__["b"] = sendAction;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__webview__ = __webpack_require__(1);


function open(identifier) {
  var path = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'index.html';
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  // Sensible defaults for options
  var _options$width = options.width,
      width = _options$width === undefined ? 300 : _options$width,
      _options$height = options.height,
      height = _options$height === undefined ? 350 : _options$height,
      _options$title = options.title,
      title = _options$title === undefined ? 'ICG DS Data Table Generator' : _options$title;


  var frame = NSMakeRect(0, 0, width, height);
  var masks = NSTitledWindowMask | NSWindowStyleMaskClosable;
  var window = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(frame, masks, NSBackingStoreBuffered, false);

  // We use this dictionary to have a persistant storage of our NSWindow/NSPanel instance
  // Otherwise the instance is stored nowhere and gets release => Window closes
  var threadDictionary = NSThread.mainThread().threadDictionary();
  threadDictionary[identifier] = window;

  var webView = Object(__WEBPACK_IMPORTED_MODULE_0__webview__["a" /* createWebView */])(path, frame);

  window.title = title;
  window.center();
  window.contentView().addSubview(webView);

  window.makeKeyAndOrderFront(null);
}

function findWebView(identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary();
  var window = threadDictionary[identifier];
  return window.contentView().subviews()[0];
}

function sendAction(identifier, name) {
  var payload = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  return Object(__WEBPACK_IMPORTED_MODULE_0__webview__["c" /* sendAction */])(findWebView(identifier), name, payload);
}

/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = toggle;
/* unused harmony export open */
/* unused harmony export close */
/* unused harmony export isOpen */
/* unused harmony export findWebView */
/* harmony export (immutable) */ __webpack_exports__["a"] = sendAction;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__core__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__formatter__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__webview__ = __webpack_require__(1);




function toggle(identifier, path, width) {
  if (isOpen(identifier)) {
    close(identifier);
  } else {
    open(identifier, path, width);
  }
}

function open(identifier) {
  var path = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'index.html';
  var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var width = options.width;

  var frame = NSMakeRect(0, 0, width || 250, 600); // the height doesn't really matter here
  var contentView = __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].documentWindow().contentView();
  if (!contentView || isOpen()) {
    return false;
  }

  var stageView = contentView.subviews().objectAtIndex(0);
  var webView = Object(__WEBPACK_IMPORTED_MODULE_2__webview__["a" /* createWebView */])(path, frame);
  webView.identifier = identifier;

  // Inject our webview into the right spot in the subview list
  var views = stageView.subviews();
  var finalViews = [];
  var pushedWebView = false;
  for (var i = 0; i < views.count(); i++) {
    var view = views.objectAtIndex(i);
    finalViews.push(view);
    // NOTE: change the view identifier here if you want to add
    //  your panel anywhere else
    if (!pushedWebView && view.identifier() == 'view_canvas') {
      finalViews.push(webView);
      pushedWebView = true;
    }
  }
  // If it hasn't been pushed yet, push our web view
  // E.g. when inspector is not activated etc.
  if (!pushedWebView) {
    finalViews.push(webView);
  }
  // Finally, update the subviews prop and refresh
  stageView.subviews = finalViews;
  stageView.adjustSubviews();
}

function close(identifier) {
  var contentView = __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].documentWindow().contentView();
  if (!contentView) {
    return false;
  }
  // Search for web view panel
  var stageView = contentView.subviews().objectAtIndex(0);
  var finalViews = Object(__WEBPACK_IMPORTED_MODULE_1__formatter__["a" /* toArray */])(stageView.subviews()).filter(function (view) {
    return view.identifier() != identifier;
  });
  stageView.subviews = finalViews;
  stageView.adjustSubviews();
}

function isOpen(identifier) {
  return !!findWebView(identifier);
}

function findWebView(identifier) {
  var contentView = __WEBPACK_IMPORTED_MODULE_0__core__["a" /* document */].documentWindow().contentView();
  if (!contentView) {
    return false;
  }
  var splitView = contentView.subviews().objectAtIndex(0);
  var views = Object(__WEBPACK_IMPORTED_MODULE_1__formatter__["a" /* toArray */])(splitView.subviews());
  return views.find(function (view) {
    return view.identifier() == identifier;
  });
}

function sendAction(identifier, name) {
  var payload = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};

  return Object(__WEBPACK_IMPORTED_MODULE_2__webview__["c" /* sendAction */])(findWebView(identifier));
}

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = toArray;
function toArray(object) {
  if (Array.isArray(object)) {
    return object;
  }
  var arr = [];
  for (var j = 0; j < object.count(); j++) {
    arr.push(object.objectAtIndex(j));
  }
  return arr;
}

/***/ })
/******/ ]);

var helloWorld = handlers.helloWorld;

var openWindow = handlers.openWindow;

var togglePanel = handlers.togglePanel;

var handleBridgeMessage = handlers.handleBridgeMessage;

var sendMessageToWindow = handlers.sendMessageToWindow;

var sendMessageToPanel = handlers.sendMessageToPanel;

var sendRequest = handlers.sendRequest;

var handleHttpResponse = handlers.handleHttpResponse;