import BrowserWindow from 'sketch-module-web-view'
import { getWebview } from 'sketch-module-web-view/remote'
import UI from 'sketch/ui'
import sketch from 'sketch'

const webviewIdentifier = 'icg-utilities.webview'

export default function () {
  var getSelectedDocument = require('sketch/dom').getSelectedDocument;
  var getAllLibs = require('sketch/dom').getLibraries;
  const library = getAllLibs()
  const document = getSelectedDocument(); 
  const page = document.pages.find(obj => obj.selected ===true);
  const artboard = page.layers.find(obj => obj.selected === true);
  const selectedLayers = document.selectedLayers;
  const selectedCount = selectedLayers.length
  const options = {
    identifier: webviewIdentifier,
    width: 240,
    height: 180,
    show: false,
    alwaysOnTop: true
  }

  const browserWindow = new BrowserWindow(options)

  // only show the window when the page has loaded to avoid a white flash
  browserWindow.once('ready-to-show', () => {
    browserWindow.show()
  })

  const webContents = browserWindow.webContents

  // print a message when the page loads
  webContents.on('did-finish-load', () => {
    UI.message('UI loaded!')
    webContents
    .executeJavaScript()
    .catch(console.error)
})

  // add a handler for a call from web content's javascript
//  webContents.on('nativeLog', s => {
 //   UI.message(s)
    // webContents
    //   .executeJavaScript(`sendMessage()`)
    //   .catch(console.error)
//  })

  browserWindow.webContents.on('nativeLog', function (cols, rows, theme, size){
  // UI.message(cols)
  //return 'result',
  //console.log('number of cols: '+cols,'\n','number of rows: '+rows)

  //UI.message('Generating a '+size.slice(3)+' Datatable with '+cols+' Columns & '+rows+' Rows!');

  let icgdsLib = library.find(obj => obj.name === theme)

  let symbolReferences = icgdsLib.getImportableSymbolReferencesForDocument(document)

  let headerCell = symbolReferences.find(obj => obj.name == 'Data Table/Cell/'+size+'/01 Column Header/01 Standard/01 Standard- Left Aligned')
  let tableCell = symbolReferences.find(obj => obj.name == 'Data Table/ Cell/ '+size+'/02 Standard Cell/ 01 Text (Left Align)/ 01 Default')

  //create and position header
  for (let i = 0; i < cols; i++){

    let symbol = headerCell.import()
    var instance = symbol.createNewInstance()
    let width = instance.frame.width
    
    instance.frame.x = instance.frame.x+width*i
    instance.parent = artboard

  }

  //create and position rest of cells
  for (let y = 0; y < rows; y++){

    let symbolY = tableCell.import()
    var instanceY = symbolY.createNewInstance()
    let height = instanceY.frame.height

    instanceY.frame.y = instanceY.frame.y+height*y+parseInt(size.slice('0,2'))
    instanceY.parent = artboard

    for (let x = 0; x < cols; x++){

      let symbolX = tableCell.import()
      var instanceX = symbolX.createNewInstance()
      let width = instanceX.frame.width
      
      instanceX.frame.x = instanceX.frame.x+width*x
      instanceX.frame.y = instanceY.frame.y
      instance.parent = artboard

    }
  }

  })

  browserWindow.loadURL(require('../resources/webview.html'))
}

// When the plugin is shutdown by Sketch (for example when the user disable the plugin)
// we need to close the webview if it's open
export function onShutdown() {
  const existingWebview = getWebview(webviewIdentifier)
  if (existingWebview) {
    existingWebview.close()
  }
}
