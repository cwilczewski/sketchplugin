// disable the context menu (eg. the right click menu) to have a more native feel
// document.addEventListener('contextmenu', (e) => {
//   e.preventDefault()
// })

var cols = {};
var rows = {};
var size = {};
var theme = {};

//call the plugin from the webview
document.getElementById('button').addEventListener('click', () => {
  cols = document.getElementById('numOfCols').value;
  rows = document.getElementById('numOfRows').value;
  size = document.getElementById('selectSize').value;
  theme = document.querySelector('input[name="themeSelect"]:checked').value;
  //console.log('from button click '+ cols, rows, size, theme)
  window.postMessage('nativeLog', cols, rows, theme, size)
})
// call the webview from the plugin
window.sendMessage = () => {

}
